package com.policia.persistencia.tablas;

/**
 * Created by 1085253556 on 23/11/2017.
 */

public class Tabla_LIBRO {

    public Tabla_LIBRO(String id, String descripcion, int vigente, String id_nivel) {
        this.ID = id;
        this.DESCRIPCION = descripcion;
        this.VIGENTE = vigente;
        this.NIVEL_ID = id_nivel;
    }

    public String ID;
    public String DESCRIPCION;
    public int VIGENTE;
    public String NIVEL_ID;
}
