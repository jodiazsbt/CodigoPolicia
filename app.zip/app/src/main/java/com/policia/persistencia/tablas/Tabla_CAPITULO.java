package com.policia.persistencia.tablas;

/**
 * Created by 1085253556 on 23/11/2017.
 */

public class Tabla_CAPITULO {

    public Tabla_CAPITULO(String id, String descripcion, boolean vigente, String id_nivel, String id_titulo) {
        this.ID = id;
        this.DESCRIPCION = descripcion;
        this.VIGENTE = vigente;
        this.NIVEL_ID = id_nivel;
        this.TITULO_ID = id_titulo;
    }

    public String ID;
    public String DESCRIPCION;
    public boolean VIGENTE;
    public String NIVEL_ID;
    public String TITULO_ID;
}
