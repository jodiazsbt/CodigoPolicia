package com.policia.persistencia.tablas;

/**
 * Created by 1085253556 on 23/11/2017.
 */

public class Tabla_ARTICULO {

    public Tabla_ARTICULO(String id, String titulo, String descripcion, boolean vigente, String id_nivel, String id_capitulo) {
        this.ID = id;
        this.TITULO = titulo;
        this.DESCRIPCION = descripcion;
        this.VIGENTE = vigente;
        this.NIVEL_ID = id_nivel;
        this.CAPITULO_ID = id_capitulo;
    }

    public String ID;
    public String TITULO;
    public String DESCRIPCION;
    public boolean VIGENTE;
    public String NIVEL_ID;
    public String CAPITULO_ID;
}
