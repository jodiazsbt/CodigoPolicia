package com.policia.codigopolicia.idioma;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.policia.codigopolicia.R;

import java.util.ArrayList;

/**
 * Created by 1085253556 on 5/12/2017.
 */

public class Idioma_Adapter extends BaseAdapter {

    Activity context;
    String[] idiomas;

    public Idioma_Adapter(Activity context, String[] idiomas) {

        this.context = context;
        this.idiomas = idiomas;
    }

    @Override
    public int getCount() {
        return idiomas.length;
    }

    @Override
    public Object getItem(int posicion) {
        return idiomas[posicion];
    }

    @Override
    public long getItemId(int posicion) {
        return posicion;
    }

    @Override
    public View getView(int posicion, View view, ViewGroup parent) {

        view = context.getLayoutInflater().inflate(R.layout.idioma_listitem, null);

        TextView textViewIdioma = view.findViewById(R.id.textViewIdioma);
        textViewIdioma.setText(idiomas[posicion]);

        return view;
    }
}
