package com.policia.codigopolicia;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.policia.codigopolicia.idioma.Idioma_Adapter;

public class IdiomaActivity extends Activity {

    private ListView listViewIdiomas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.idioma_activity);

        listViewIdiomas = findViewById(R.id.listViewIdiomas);
        listViewIdiomas.addHeaderView(getLayoutInflater().inflate(R.layout.idioma_header, null), null, false);
        listViewIdiomas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                view.setSelected(true);
            }
        });
        listViewIdiomas.setAdapter(
                new Idioma_Adapter(
                        this,
                        getResources().getStringArray(R.array.language_list)));
    }
}
