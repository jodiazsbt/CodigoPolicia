package com.policia.remote.request;

/**
 * Created by 1085253556 on 12/12/2017.
 */

public class RequestLogin {

    public String Usuario;
    public String Contrasena;
    public String DireccionIP;
    public String NombreAplicacion;

    public RequestLogin() {
    }
}
