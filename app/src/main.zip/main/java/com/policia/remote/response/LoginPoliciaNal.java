package com.policia.remote.response;

import java.io.Serializable;

import java.util.List;

/**
 * Created by 1085253556 on 12/12/2017.
 */

public class LoginPoliciaNal implements Serializable {

    public LoginPoliciaNal() {
    }

    public List<LoginPoliciaNalResult> LoginPoliciaNalResult;

}

