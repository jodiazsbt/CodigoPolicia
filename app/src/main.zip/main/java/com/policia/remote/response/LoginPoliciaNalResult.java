package com.policia.remote.response;

import java.io.Serializable;

public class LoginPoliciaNalResult implements Serializable {

    public LoginPoliciaNalResult() {
    }

    public String Cargo;
    public String Consecutivo;
    public String Fisica;
    public String Funcionario;
    public String Grado;
    public String Identificacion;
    public String Placa;
    public String UndeConsecutivo;
    public String UndeFuerza;
    public String UnderLabora;
    public String Unidad;
    public int Verifica;
}
