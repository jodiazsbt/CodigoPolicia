package com.policia.negocio.modelo;

/**
 * Created by 1085253556 on 14/12/2017.
 */

public class Modelo_NUMERAL {
}
