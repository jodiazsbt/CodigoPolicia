package com.policia.negocio.modelo;

/**
 * Created by 1085253556 on 8/12/2017.
 */

public class Modelo_IDIOMA {

    public Modelo_IDIOMA(String Codigo, String Idioma, boolean Seleccion) {

        this.CODIGO = Codigo;
        this.IDIOMA = Idioma;
        this.SELECCION = Seleccion;

    }

    public String CODIGO;
    public String IDIOMA;
    public boolean SELECCION;
}
