package com.policia.persistencia.tablas;

import java.util.Date;

/**
 * Created by 1085253556 on 6/12/2017.
 */

public class Tabla_METADATA {

    public Tabla_METADATA()
    {}

    public String ID;
    public String METADATA_ESP;
    public String METADATA_ENG;
    public boolean ACTIVO;
    public String ARTICULO_ID;
    public Date FECHA;
}
