package com.policia.persistencia.tablas;

import java.util.Date;

/**
 * Created by 1085253556 on 7/12/2017.
 */

public class Tabla_MULTA {

    public Tabla_MULTA(){}

    public String NUMERAL_ID;
    public String MEDIDA_ID;
    public boolean VIGENTE;
    public Date FECHA;
    public String TIPOMULTA_ID;
}
