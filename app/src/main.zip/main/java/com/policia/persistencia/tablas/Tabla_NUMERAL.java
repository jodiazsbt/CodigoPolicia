package com.policia.persistencia.tablas;

import java.util.Date;

/**
 * Created by 1085253556 on 6/12/2017.
 */

public class Tabla_NUMERAL {

    public Tabla_NUMERAL(){}

    public String ID;
    public String NUMERAL_ESP;
    public String NUMERAL_ENG;
    public boolean VIGENTE;
    public String NIVEL_ID;
    public String ARTICULO_ID;
    public Date FECHA;
}
