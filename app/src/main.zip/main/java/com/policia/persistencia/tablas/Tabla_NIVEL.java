package com.policia.persistencia.tablas;

import java.util.Date;

/**
 * Created by 1085253556 on 6/12/2017.
 */

public class Tabla_NIVEL {

    public Tabla_NIVEL(){}

    public String ID;
    public String NIVEL_ESP;
    public String NIVEL_ENG;
    public boolean VIGENTE;
    public Date FECHA;
}
