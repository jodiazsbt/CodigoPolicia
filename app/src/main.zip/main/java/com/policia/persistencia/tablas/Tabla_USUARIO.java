package com.policia.persistencia.tablas;

/**
 * Created by 1085253556 on 7/12/2017.
 */

public class Tabla_USUARIO {

    public Tabla_USUARIO(){}

    public String ID;
    public String CONSECUTIVO;
    public String FISICA;
    public String FUNCIONARIO;
    public String IDENTIFICACION;
    public String PLACA;
    public String UNDECONSECUTIVO;
    public String UNDEFUERZA;
    public String UNDELABORA;
    public String UNIDAD;
    public boolean VERIFICA;
}
