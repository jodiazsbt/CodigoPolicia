package com.policia.persistencia.tablas;

import java.util.Date;

/**
 * Created by 1085253556 on 23/11/2017.
 */

public class Tabla_LIBRO {

    public Tabla_LIBRO() {
    }

    public String ID;
    public String LIBRO_ESP;
    public String LIBRO_ENG;
    public boolean VIGENTE;
    public String NIVEL_ID;
    public Date FECHA;
}
