package com.policia.persistencia.tablas;

/**
 * Created by 1085253556 on 7/12/2017.
 */

public class Tabla_PREFERENCIA {

    public Tabla_PREFERENCIA(){}

    public String USUARIO_ID;
    public String IDIOMA_CODIGO;
}
