package com.policia.persistencia.tablas;

import java.util.Date;

/**
 * Created by 1085253556 on 23/11/2017.
 */

public class Tabla_CAPITULO {

    public Tabla_CAPITULO() {
    }

    public String ID;
    public String CAPITULO_ESP;
    public String CAPITULO_ENG;
    public boolean VIGENTE;
    public String NIVEL_ID;
    public String TITULO_ID;
    public Date FECHA;
}
