package com.policia.persistencia.tablas;

import java.util.Date;

/**
 * Created by 1085253556 on 23/11/2017.
 */

public class Tabla_ARTICULO {

    public Tabla_ARTICULO() {
    }

    public String ID;
    public String TITULO_ESP;
    public String TITULO_ENG;
    public String ARTICULO_ESP;
    public String ARTICULO_ENG;
    public boolean VIGENTE;
    public String NIVEL_ID;
    public String CAPITULO_ID;
    public Date FECHA;
}
