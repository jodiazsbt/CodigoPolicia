package com.policia.persistencia.tablas;

import java.util.Date;

/**
 * Created by 1085253556 on 7/12/2017.
 */

public class Tabla_SESION {

    public Tabla_SESION() {
    }

    public String USUARIO_ID;
    public Date FECHA;
}
