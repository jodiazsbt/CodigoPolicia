package com.policia.codigopolicia.NavegacionMULTAS;

import com.policia.negocio.modelo.ValuePar;

import java.util.ArrayList;

/**
 * Created by 1085253556 on 30/11/2017.
 */

public class Detalle_ARTICULO {

    public Detalle_ARTICULO(ArrayList<ValuePar> Valores) {
        this.Valores = Valores;
    }

    public ArrayList<ValuePar> Valores;
}
