package com.policia.codigopolicia.adapter;

import android.widget.TextView;

/**
 * Created by JORGE on 3/12/2017.
 */

public class ViewHolder {

    TextView textLIBRO, textTITULO, textCAPITULO, textARTICULO;
}
