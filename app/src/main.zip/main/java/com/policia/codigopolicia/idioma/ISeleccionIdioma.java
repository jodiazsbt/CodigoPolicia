package com.policia.codigopolicia.idioma;

/**
 * Created by 1085253556 on 9/12/2017.
 */

public interface ISeleccionIdioma {

    void Seleccion(int position);
}
