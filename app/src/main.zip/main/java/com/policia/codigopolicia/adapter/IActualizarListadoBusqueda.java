package com.policia.codigopolicia.adapter;

/**
 * Created by 1085253556 on 4/12/2017.
 */

public interface IActualizarListadoBusqueda {

    void actualizar(String termino_busqueda);
}
